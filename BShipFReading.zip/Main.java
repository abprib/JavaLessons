import java.io.File;
import java.util.Scanner;

class Main {
  public static void main(String[] losArgumentos){
    char[][] rField = new char[10][10];
    try{
      File file = new File("field.txt");
      Scanner sc = new Scanner(file);
      StringBuilder str = new StringBuilder();
      for(int i = 0; i < 10; i++){
        str.replace(0, 9, sc.next());
        for(int j = 0; j < 10; j++){
          rField[i][j] = str.charAt(j);
          System.out.print(rField[i][j]);
        }
        System.out.println(" ");
      }
      sc.close();
    } catch(Exception e){
      System.out.println("File not found");
    } 
  }
}


